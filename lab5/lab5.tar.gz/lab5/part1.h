//
//  part1.h
//  lab5
//
//  Created by Xiang on 2017/11/3.
//  Copyright © 2017年 xianng. All rights reserved.
//

#ifndef part1_h
#define part1_h

#include <stdio.h>
#include <string.h>

void setJediName(char *firstName, char *lastName, char buffer[]);

void printName(char *first, char *last, char *buffer);

#endif /* part1_h */
