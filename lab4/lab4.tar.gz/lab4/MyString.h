//
//  MyString.h
//  lab4
//
//  Created by Xiang on 2017/10/23.
//  Copyright © 2017年 xianng. All rights reserved.
//

#ifndef MyString_h
#define MyString_h

#include <stdio.h>

int strLenth(char *string);

int myStrStr(char  haystack[], char needle[], char buffer[]);


#endif /* MyString_h */
